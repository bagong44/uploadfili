1. Please DO NOT open pull request on the **master** branch. Use the **develop** branch instead!
2. Explain your changes as much as possible
3. If possible, use a well understanding title (e.g: "[Bug] Google Captcha", "[Feature] Footprinting on Bing")

Thank you for contributing ! :tada:
